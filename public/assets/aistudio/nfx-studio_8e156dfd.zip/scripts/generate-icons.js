// Pure Node.js script to generate valid PNG icon files for PWA
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPng(width, height, isMaskable) {
  // RGBA buffer: width * height * 4
  const buffer = Buffer.alloc(width * height * 4);

  const cx = width / 2;
  const cy = height / 2;
  const radius = isMaskable ? width * 0.45 : width * 0.42;

  // Background gradient: #0a6cf0 to #4b3fd8
  for (let y = 0; y < height; y++) {
    const t = y / height;
    const rBg = Math.round(10 * (1 - t) + 75 * t);
    const gBg = Math.round(108 * (1 - t) + 63 * t);
    const bBg = Math.round(240 * (1 - t) + 216 * t);

    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;

      if (isMaskable) {
        // Full bleed background
        buffer[idx] = rBg;
        buffer[idx + 1] = gBg;
        buffer[idx + 2] = bBg;
        buffer[idx + 3] = 255;
      } else {
        // Rounded squircle / rounded rect with anti-aliasing
        const cornerR = width * 0.22;
        const dx = Math.abs(x - cx) - (cx - cornerR);
        const dy = Math.abs(y - cy) - (cy - cornerR);
        const dist = Math.sqrt(Math.max(0, dx) ** 2 + Math.max(0, dy) ** 2);
        
        if (dx <= 0 || dy <= 0 || dist <= cornerR) {
          buffer[idx] = rBg;
          buffer[idx + 1] = gBg;
          buffer[idx + 2] = bBg;
          buffer[idx + 3] = 255;
        } else {
          buffer[idx] = 0;
          buffer[idx + 1] = 0;
          buffer[idx + 2] = 0;
          buffer[idx + 3] = 0;
        }
      }

      // Draw stylized 'N' logo in center (white)
      // Scale factor: inside safe zone (e.g. 50% of icon width/height)
      const nScale = isMaskable ? 0.45 : 0.52;
      const nw = width * nScale;
      const nh = height * nScale;
      const nx1 = cx - nw / 2;
      const nx2 = cx + nw / 2;
      const ny1 = cy - nh / 2;
      const ny2 = cy + nh / 2;
      const colW = nw * 0.22;

      if (x >= nx1 && x <= nx2 && y >= ny1 && y <= ny2) {
        let insideN = false;
        // Left column
        if (x <= nx1 + colW) {
          insideN = true;
        }
        // Right column
        else if (x >= nx2 - colW) {
          insideN = true;
        }
        // Diagonal bridge from top-left to bottom-right
        else {
          const progress = (y - ny1) / nh;
          const diagX = nx1 + progress * (nw - colW);
          if (x >= diagX && x <= diagX + colW * 1.1) {
            insideN = true;
          }
        }

        if (insideN && buffer[idx + 3] > 0) {
          buffer[idx] = 255;
          buffer[idx + 1] = 255;
          buffer[idx + 2] = 255;
          buffer[idx + 3] = 255;
        }
      }
    }
  }

  // Construct PNG with scanlines (filter type 0: None)
  const rowSize = width * 4 + 1;
  const rawData = Buffer.alloc(rowSize * height);
  for (let y = 0; y < height; y++) {
    rawData[y * rowSize] = 0; // Filter None
    buffer.copy(rawData, y * rowSize + 1, y * width * 4, (y + 1) * width * 4);
  }

  const compressed = zlib.deflateSync(rawData);

  function createChunk(type, data) {
    const len = data.length;
    const buf = Buffer.alloc(12 + len);
    buf.writeUInt32BE(len, 0);
    buf.write(type, 4, 4, 'ascii');
    data.copy(buf, 8);
    // CRC32 calculation
    const crc = crc32(buf.subarray(4, 8 + len));
    buf.writeUInt32BE(crc, 8 + len);
    return buf;
  }

  // CRC32 table
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c ^= buf[i];
      for (let j = 0; j < 8; j++) {
        c = (c >>> 1) ^ (-(c & 1) & 0xedb88320);
      }
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 192x192
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPng(192, 192, false));
// 512x512
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPng(512, 512, false));
// 512x512 maskable (full bleed background with padded safe zone)
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPng(512, 512, true));
// 180x180 apple touch icon
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPng(180, 180, false));

console.log('PWA PNG icons generated successfully!');
