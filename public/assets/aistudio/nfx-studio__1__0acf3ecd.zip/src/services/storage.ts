import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Project, APKItem } from '../types';

interface NFXStudioDB extends DBSchema {
  projects: {
    key: string;
    value: Project;
    indexes: { 'by-updated': number };
  };
  apks: {
    key: string;
    value: APKItem;
    indexes: { 'by-date': string };
  };
}

const DB_NAME = 'nfx-studio-db';
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<NFXStudioDB>> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB<NFXStudioDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('projects')) {
          const projectStore = db.createObjectStore('projects', { keyPath: 'id' });
          projectStore.createIndex('by-updated', 'ts');
        }
        if (!db.objectStoreNames.contains('apks')) {
          const apkStore = db.createObjectStore('apks', { keyPath: 'id' });
          apkStore.createIndex('by-date', 'date');
        }
      },
    });
  }
  return dbPromise;
}

// Clean up any legacy localStorage seed data once
export function cleanLegacyStorage() {
  try {
    const legacyProjects = localStorage.getItem('nfx-projects');
    if (legacyProjects) {
      // Check if it contained fake seed data
      if (legacyProjects.includes('GreenLife') || legacyProjects.includes('ShopEasy')) {
        localStorage.removeItem('nfx-projects');
      }
    }
    const legacyApks = localStorage.getItem('nfx-apks');
    if (legacyApks) {
      if (legacyApks.includes('GreenLife') || legacyApks.includes('ShopEasy')) {
        localStorage.removeItem('nfx-apks');
      }
    }
  } catch {}
}

export async function getAllProjects(): Promise<Project[]> {
  const db = await getDB();
  const projects = await db.getAll('projects');
  // Sort descending by timestamp
  return projects.sort((a, b) => (b.ts || 0) - (a.ts || 0));
}

export async function saveProject(project: Project): Promise<void> {
  const db = await getDB();
  await db.put('projects', project);
}

export async function deleteProject(id: string): Promise<void> {
  const db = await getDB();
  await db.delete('projects', id);
}

export async function clearAllProjects(): Promise<void> {
  const db = await getDB();
  await db.clear('projects');
}

export async function getAllAPKs(): Promise<APKItem[]> {
  const db = await getDB();
  return await db.getAll('apks');
}

export async function saveAPK(apk: APKItem): Promise<void> {
  const db = await getDB();
  await db.put('apks', apk);
}

export async function deleteAPK(id: string): Promise<void> {
  const db = await getDB();
  await db.delete('apks', id);
}

export async function clearAllAPKs(): Promise<void> {
  const db = await getDB();
  await db.clear('apks');
}
